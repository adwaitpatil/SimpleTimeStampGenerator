package com.adwait.epochconverter.gui;

import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.BoxLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.Box;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.text.DefaultEditorKit;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;


@SuppressWarnings("serial")
public class RootPanel extends JPanel
{
	private JTextField txtCurrentDateTime;
	private JTextField txtUnixTimestampDec;
	private JTextField txtUnixTimestampHex;
	
	public RootPanel()
	{
		//Overall
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), new EmptyBorder(20, 20, 20, 20)));
		
		
		// Cut Copy Paste Context Menus
		JPopupMenu popup = new JPopupMenu();
		JMenuItem item = new JMenuItem(new DefaultEditorKit.CutAction());
		item.setText("Cut");
		popup.add(item);
		item = new JMenuItem(new DefaultEditorKit.CopyAction());
		item.setText("Copy");
		popup.add(item);
		item = new JMenuItem(new DefaultEditorKit.PasteAction());
		item.setText("Paste");
		popup.add(item);
				
		//Will contain system date and time		
		txtCurrentDateTime = new JTextField();
		txtCurrentDateTime.setHorizontalAlignment(SwingConstants.CENTER);
		txtCurrentDateTime.setEnabled(false);
		txtCurrentDateTime.setEditable(false);
		txtCurrentDateTime.setToolTipText("Local Date & Time");
		add(txtCurrentDateTime);
		txtCurrentDateTime.setColumns(10);
		
		add(Box.createVerticalStrut(20));
		
		//Will contain the converted Unix Time-stamp in decimal
		txtUnixTimestampDec = new JTextField();
		txtUnixTimestampDec.setEditable(false);
		txtUnixTimestampDec.setHorizontalAlignment(SwingConstants.CENTER);
		txtUnixTimestampDec.setEnabled(true);
		txtUnixTimestampDec.setToolTipText("Unix Timestamp (In Decimal)");
		add(txtUnixTimestampDec);
		txtUnixTimestampDec.setColumns(10);
		txtUnixTimestampDec.setComponentPopupMenu(popup);

		add(Box.createVerticalStrut(20));
		
		////Will contain the converted Unix Time-stamp in hexadecimal
		txtUnixTimestampHex = new JTextField();
		txtUnixTimestampHex.setEditable(false);
		txtUnixTimestampHex.setHorizontalAlignment(SwingConstants.CENTER);
		txtUnixTimestampHex.setEnabled(true);
		txtUnixTimestampHex.setToolTipText("Unix Timestamp (In Hexadecimal)");
		add(txtUnixTimestampHex);
		txtUnixTimestampHex.setColumns(10);
		txtUnixTimestampHex.setComponentPopupMenu(popup);
		add(Box.createVerticalStrut(20));
		
		//panelButton houses the 'Generate' and 'Clear'
		JPanel panelButtons = new JPanel();
		add(panelButtons);
		JButton btnGenerate = new JButton("Generate");
		btnGenerate.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				long unixTime = System.currentTimeMillis() / 1000L;
				//TODO: Make generic
				unixTime = unixTime + 19800;								//Indian Standard Time
				txtUnixTimestampDec.setText(Long.toString(unixTime));
				txtUnixTimestampHex.setText(String.format("%X",unixTime));
			}
		});
		panelButtons.add(btnGenerate);
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				txtUnixTimestampDec.setText("");
				txtUnixTimestampHex.setText("");
			}
		});
		panelButtons.add(btnClear);
		
		
		
		/*Time Updater Daemon*/
		Runnable r = new Runnable()
		{
			@Override
			public void run()
			{
				LocalTime nowTime;
				LocalDate nowDate;
				String day;
				String date;
				String time;
				
				while(true)
				{
					//Delay the start of daemon by 0.1 seconds
					try
					{TimeUnit.MILLISECONDS.sleep(100);} 
					catch (InterruptedException e1)	{e1.printStackTrace();}
					
					nowTime = LocalTime.now();
					nowDate = LocalDate.now();
					
					day = nowDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault());
					date = ""+nowDate.getDayOfMonth()+"/"+nowDate.getMonthValue()+"/"+nowDate.getYear();
					time = nowTime.toString();
					time = time.substring(0, time.length()-4);
					txtCurrentDateTime.setText(day + " " + date + " " + time);
				}				
			}
		};
		Thread th = new Thread(r);
		th.start();
		
	}

}
