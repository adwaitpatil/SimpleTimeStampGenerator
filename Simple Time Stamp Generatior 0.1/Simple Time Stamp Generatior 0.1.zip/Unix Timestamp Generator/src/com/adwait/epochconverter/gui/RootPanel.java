package com.adwait.epochconverter.gui;

import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.Box;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;


@SuppressWarnings("serial")
public class RootPanel extends JPanel
{
	private JTextField txtCurrentDateTime;
	private JTextField txtUnixTimestampDec;
	private JTextField txtUnixTimestampHex;
	
	public RootPanel()
	{
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setBorder(new CompoundBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), new EmptyBorder(20, 20, 20, 20)));
		
		txtCurrentDateTime = new JTextField();
		txtCurrentDateTime.setHorizontalAlignment(SwingConstants.CENTER);
		txtCurrentDateTime.setEnabled(false);
		txtCurrentDateTime.setEditable(false);
		txtCurrentDateTime.setToolTipText("Local Date & Time");
		add(txtCurrentDateTime);
		txtCurrentDateTime.setColumns(10);
		
		add(Box.createVerticalStrut(20));
		
		txtUnixTimestampDec = new JTextField();
		txtUnixTimestampDec.setHorizontalAlignment(SwingConstants.CENTER);
		txtUnixTimestampDec.setEnabled(true);
		txtUnixTimestampDec.setEditable(false);
		txtUnixTimestampDec.setToolTipText("Unix Timestamp (In Decimal)");
		add(txtUnixTimestampDec);
		txtUnixTimestampDec.setColumns(10);

		add(Box.createVerticalStrut(20));
		
		txtUnixTimestampHex = new JTextField();
		txtUnixTimestampHex.setHorizontalAlignment(SwingConstants.CENTER);
		txtUnixTimestampHex.setEnabled(true);
		txtUnixTimestampHex.setEditable(false);
		txtUnixTimestampHex.setToolTipText("Unix Timestamp (In Hexadecimal)");
		add(txtUnixTimestampHex);
		txtUnixTimestampHex.setColumns(10);

		add(Box.createVerticalStrut(20));
		
		
		JPanel panelButtons = new JPanel();
		add(panelButtons);
		JButton btnGenerate = new JButton("Generate");
		btnGenerate.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				long unixTime = System.currentTimeMillis() / 1000L;
				unixTime = unixTime + 19800;								//Indian Standard Time
				txtUnixTimestampDec.setText(Long.toString(unixTime));
				txtUnixTimestampHex.setText(String.format("%X",unixTime));
			}
		});
		panelButtons.add(btnGenerate);
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				txtUnixTimestampDec.setText("");
				txtUnixTimestampHex.setText("");
			}
		});
		panelButtons.add(btnClear);
		
		/*Time Updater Daemon*/
		Runnable r = new Runnable()
		{
			@Override
			public void run()
			{
				LocalTime nowTime;
				LocalDate nowDate;
				String day;
				String date;
				String time;
				
				//Delay the start of daemon by 1 seconds
				try
				{TimeUnit.MILLISECONDS.sleep(1000);} 
				catch (InterruptedException e1)	{e1.printStackTrace();}
				
				while(true)
				{
					nowTime = LocalTime.now();
					nowDate = LocalDate.now();
					
					day = nowDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.getDefault());
					date = ""+nowDate.getDayOfMonth()+"/"+nowDate.getMonthValue()+"/"+nowDate.getYear();
					time = nowTime.toString();
					txtCurrentDateTime.setText(day + " " + date + " " + time);
				}				
			}
		};
		Thread th = new Thread(r);
		th.start();
		
	}

}
