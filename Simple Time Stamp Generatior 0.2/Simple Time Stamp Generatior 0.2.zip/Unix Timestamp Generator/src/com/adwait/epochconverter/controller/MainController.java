package com.adwait.epochconverter.controller;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

import com.adwait.epochconverter.gui.RootPanel;



public class MainController
{
	JFrame frame;
	RootPanel rootPanel;

	public static void main(String[] args)
	{
		// Setting the look and feel
		// setLookAndFeel("Windows");
		// setLookAndFeel("Nimbus");
		// setLookAndFeel("CDE/Motif");
		// setLookAndFeel("Metal");
		 setLookAndFeel("Mac");
		// setLookAndFeel("JTatto");
		 
		/*Initializations*/
		MainController contoller = new MainController();

		/*Getting the screen size*/
		Dimension monitorDimensions = Toolkit.getDefaultToolkit().getScreenSize();
		
		/*The 'root' JFrame*/
		contoller.frame = new JFrame("Simple Unix Time Stamp Generator v0.1");
		contoller.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		contoller.frame.setSize(monitorDimensions.width,monitorDimensions.height-50);
		contoller.frame.setSize(new Dimension(350,250));//frame.setSize(new Dimension(770,400));
	    //frame.setExtendedState(java.awt.Frame.MAXIMIZED_BOTH);
	    //frame.setUndecorated(true);
		contoller.frame.setResizable(false);
		contoller.frame.setLocationRelativeTo(null);
		
		/*Setup the panels and show the window*/
		contoller.rootPanel = new RootPanel();
		contoller.frame.getContentPane().add(contoller.rootPanel);
		contoller.frame.setVisible(true);
	}

	/*
	 * 	Sets the Look and Feel of the application's GUI
	*/
	private static void setLookAndFeel(String lafName)
	{
		try
		{
			// The MacIntosh LAF
			if (lafName.equalsIgnoreCase("Mac"))
			{
				System.setProperty("Quaqua.tabLayoutPolicy", "wrap");
				UIManager.setLookAndFeel(ch.randelshofer.quaqua.QuaquaManager.getLookAndFeel());
				return;
			}

			// JTatto LAF
			if (lafName.equalsIgnoreCase("JTatto"))
			{
				UIManager.setLookAndFeel("com.jtattoo.plaf.smart.SmartLookAndFeel");
				return;
			}

			// JRE and System LAFs
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
			{
				if (lafName.equals(info.getName()))
				{
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
			{
				if ("System".equals(info.getName()))
				{
					try
					{
						UIManager.setLookAndFeel(info.getClassName());
					} catch (Exception e1)
					{
						e1.printStackTrace();
					}
					break;
				}
			}
		}
	}
}
